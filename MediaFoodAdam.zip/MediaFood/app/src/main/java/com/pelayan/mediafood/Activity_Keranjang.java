package com.pelayan.mediafood;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class Activity_Keranjang extends AppCompatActivity {

    Button btnPesanMenu, btnBayarMenu;
    ListView listOrders;
    RecyclerView rvBarang;
    Activity_Keranjang.BarangAdapter barangAdapter;
    String searchQuery;
    ArrayList<HashMap<String, String>> itemList = new ArrayList<>();
    TextView txtIdTrans, txtIdMeja, dateView;
    String idTrans;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__keranjang);

        listOrders = (ListView) findViewById(R.id.listOrders);
        rvBarang = (RecyclerView) findViewById(R.id.rvBarang);

        txtIdMeja = (TextView)findViewById(R.id.txtIdMeja);
        txtIdTrans = (TextView)findViewById(R.id.txtIdTrans);
//        dateView = (TextView)findViewById(R.id.textView3);

        barangAdapter = new Activity_Keranjang.BarangAdapter(itemList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(Activity_Keranjang.this    );
        rvBarang.setLayoutManager(mLayoutManager);
        rvBarang.setItemAnimator(new DefaultItemAnimator());
        rvBarang.setAdapter(barangAdapter);
//
        Intent i = getIntent();
        txtIdMeja.setText(i.getStringExtra("id_meja"));
        idTrans = i.getStringExtra("id_trans");
        txtIdTrans.setText(idTrans);

        final Handler handler = new Handler();
        Runnable refresh = new Runnable() {
            @Override
            public void run() {
                new Activity_Keranjang.DbRead().execute("");
                handler.postDelayed(this, 5 * 1000);
            }
        };
        handler.postDelayed(refresh, 5 * 1000);


        new Activity_Keranjang.DbRead().execute();

        btnPesanMenu=(Button) findViewById(R.id.btnPesanMenu);
        btnBayarMenu=(Button)findViewById(R.id.btnBayarMenu);

        btnPesanMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    String[] action = {"insert"};
                    new Activity_Keranjang.DbWrite().execute(action);
                    Intent intent = new Intent(Activity_Keranjang.this, Activity_DaftarMeja.class);
                    startActivity(intent);
                    finish();

            }
        });

        btnBayarMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity_Keranjang.this, Activity_DaftarMeja.class);
                startActivity(intent);
                finish();

            }
        });


    }

    private String downloadUrl(String strUrl, @Nullable String idTrans) throws IOException {
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        String data = "";
        try {
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();

            if (idTrans != null) {
                urlConnection.setRequestMethod("POST");

                Uri.Builder builder = new Uri.Builder().appendQueryParameter("id_trans", idTrans);
                String query = builder.build().getEncodedQuery();

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
            }

            urlConnection.connect();

            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            data = sb.toString();
            br.close();
        } catch (Exception e) {
            Log.d("Download URL", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }
    private class DbRead extends AsyncTask<String, Integer, String> {

        @Override
        protected String doInBackground(String... strings) {
            String data = "";
            itemList.clear();
            String idTrans = txtIdTrans.getText().toString();
            try {
                    data = downloadUrl("http://192.168.43.134/UAS_MediaFood/read_allorderPelayan.php", idTrans);

                JSONObject jsonObject = new JSONObject(data);
                JSONArray barang = jsonObject.getJSONArray("detail_jual");
                for (int i = 0; i < barang.length(); i++) {
                    JSONObject c = barang.getJSONObject(i);
                    String idMenu = c.getString("id_menu");
                    String nmMenu = c.getString("nama_menu");
                    String hrgMenu = c.getString("hrg_menu");
                    String jmlPesan = c.getString("jml_pesan");
                    String stsPesan = c.getString("sts_pesan");
                    HashMap<String, String> item = new HashMap<>();
                    item.put("id_menu", idMenu);
                    item.put("nama_menu", nmMenu);
                    item.put("hrg_menu", hrgMenu);
                    item.put("jml_pesan", jmlPesan);
                    item.put("sts_pesan", stsPesan);
                    itemList.add(item);
                }

            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            barangAdapter.notifyDataSetChanged();
        }
    }


    public class BarangAdapter extends RecyclerView.Adapter<Activity_Keranjang.BarangAdapter.MyViewHolder> {

        private ArrayList<HashMap<String, String>> barangList = new ArrayList<>();

        public BarangAdapter(ArrayList<HashMap<String, String>> barangList) {
            this.barangList = barangList;
        }

        @Override
        public Activity_Keranjang.BarangAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_keranjang, parent, false);

            return new Activity_Keranjang.BarangAdapter.MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final Activity_Keranjang.BarangAdapter.MyViewHolder holder, int position) {

            final HashMap<String, String> barang = barangList.get(position);

            int jml = Integer.valueOf(barang.get("jml_pesan"));
            int harga = Integer.valueOf(barang.get("hrg_menu"));
            int hargaSub = harga*jml;

            holder.txtNamaMenu.setText("Nama Menu\t: " + barang.get("nama_menu"));
            holder.txtHrgMenu.setText("Harga\t: " + barang.get("hrg_menu"));
            holder.txtJmlPesan.setText("Jumlah\t\t\t: " + barang.get("jml_pesan"));
            holder.txtSubTotal.setText("Sub Total\t\t\t: " + hargaSub);
            holder.txtStsPesan.setText("Status \t: " + barang.get("sts_pesan"));


        }

        @Override
        public int getItemCount() {
            return barangList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {

            private View view;
            private TextView txtJmlPesan, txtHrgMenu, txtNamaMenu, txtStsPesan, txtSubTotal;
            private CardView cvKeranjangList;

            public MyViewHolder(View view) {
                super(view);
                this.view = view;

                txtJmlPesan = view.findViewById(R.id.txtJmlPesan);
                txtNamaMenu = view.findViewById(R.id.txtNamaMenu);
                txtHrgMenu = view.findViewById(R.id.txtHargaMenu);
                txtStsPesan = view.findViewById(R.id.txtStsPesan);
                txtSubTotal = view.findViewById(R.id.txtSubTotal);

                cvKeranjangList = view.findViewById(R.id.cvListKeranjang);
            }
        }
    }
    private String downloadUrl2(String strUrl, @Nullable String idTrans, @Nullable String idMeja) throws IOException {
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        String data = "";
        try {
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();

            if (idTrans != null) {
                urlConnection.setRequestMethod("POST");

                Uri.Builder builder = new Uri.Builder()
                        .appendQueryParameter("id_trans", idTrans)
                        .appendQueryParameter("id_meja", idMeja);
                String query = builder.build().getEncodedQuery();

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
            }

            urlConnection.connect();

            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            data = sb.toString();
            br.close();
        } catch (Exception e) {
            Log.d("Download URL", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    private class DbWrite extends AsyncTask<String, Integer, String> {

        @Override
        protected String doInBackground(String... strings) {
            String data = "";
            String action = strings[0];
            String idTrans = txtIdTrans.getText().toString();
            String idMeja = txtIdMeja.getText().toString();
            try {
                data = downloadUrl2("http://192.168.43.134/UAS_MediaFood/take_checkoutPelayan.php", idTrans, idMeja);

                JSONObject jsonObject = new JSONObject(data);
                data = jsonObject.get("success").toString();
                Log.d("Blah", action + " - " + data);

            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s.equals("1")) {
                Toast.makeText(getApplicationContext(), "Checkout Berhasil, Silahkan bayar dikasir!", Toast.LENGTH_LONG).show();
                setResult(RESULT_OK);
                finish();
            } else {
                Toast.makeText(getApplicationContext(), "Pesanan Diproses!", Toast.LENGTH_SHORT).show();
            }
        }

    }

    }
