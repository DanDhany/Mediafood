package com.pelayan.mediafood;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class Activity_DaftarMeja extends AppCompatActivity {

    ListView listOrders;
    RecyclerView rvBarang;
    Activity_DaftarMeja.BarangAdapter barangAdapter;
    String searchQuery;
    ArrayList<HashMap<String, String>> itemList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__daftar_meja);

        listOrders = (ListView) findViewById(R.id.listOrders);
        rvBarang = (RecyclerView) findViewById(R.id.rvBarang);

        barangAdapter = new Activity_DaftarMeja.BarangAdapter(itemList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(Activity_DaftarMeja.this);
        rvBarang.setLayoutManager(mLayoutManager);
        rvBarang.setItemAnimator(new DefaultItemAnimator());
        rvBarang.setAdapter(barangAdapter);

        final Handler handler = new Handler();
        Runnable refresh = new Runnable() {
            @Override
            public void run() {
                new Activity_DaftarMeja.DbRead().execute("");
                handler.postDelayed(this, 5 * 1000);
            }
        };
        handler.postDelayed(refresh, 5 * 1000);

        new Activity_DaftarMeja.DbRead().execute("");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            new Activity_DaftarMeja.DbRead().execute("");
        }
    }

    private String downloadUrl(String strUrl, @Nullable String keyword) throws IOException {
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        String data = "";
        try {
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();

            if (keyword != null) {
                urlConnection.setRequestMethod("POST");

                Uri.Builder builder = new Uri.Builder().appendQueryParameter("keyword", keyword);
                String query = builder.build().getEncodedQuery();

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
            }

            urlConnection.connect();

            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            data = sb.toString();
            br.close();
        } catch (Exception e) {
            Log.d("Download URL", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }
    private class DbRead extends AsyncTask<String, Integer, String> {

        @Override
        protected String doInBackground(String... strings) {
            String data = "";
            itemList.clear();
            String keyword = strings[0];
            try {
                if (keyword.isEmpty()) {
                    data = downloadUrl("http://192.168.43.134/UAS_MediaFood/show_pesanan.php", null);
                } else {
                    data = downloadUrl("http://192.168.43.134/UAS_MediaFood/show_pesanan.php", keyword);
                }

                JSONObject jsonObject = new JSONObject(data);
                JSONArray barang = jsonObject.getJSONArray("id");
                for (int i = 0; i < barang.length(); i++) {
                    JSONObject c = barang.getJSONObject(i);
                    String idMeja = c.getString("id_meja");
                    String ketMeja = c.getString("id_trans");
                    String stsMeja = c.getString("sts_trans");
                    HashMap<String, String> item = new HashMap<>();
                    item.put("id_meja", idMeja);
                    item.put("id_trans", ketMeja);
                    item.put("sts_trans", stsMeja);
                    itemList.add(item);
                }

            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            barangAdapter.notifyDataSetChanged();
        }
    }

    public class BarangAdapter extends RecyclerView.Adapter<Activity_DaftarMeja.BarangAdapter.MyViewHolder> {

        private ArrayList<HashMap<String, String>> barangList = new ArrayList<>();

        public BarangAdapter(ArrayList<HashMap<String, String>> barangList) {
            this.barangList = barangList;
        }

        @Override
        public Activity_DaftarMeja.BarangAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_meja, parent, false);

            return new Activity_DaftarMeja.BarangAdapter.MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final Activity_DaftarMeja.BarangAdapter.MyViewHolder holder, int position) {

            final HashMap<String, String> barang = barangList.get(position);

            holder.txtIdMeja.setText("No Meja\t\t\t: " + barang.get("id_meja"));
            holder.txtKetMeja.setText("ID Transaksi\t: " + barang.get("id_trans"));
            holder.txtStsMeja.setText("Status Meja\t: " + barang.get("sts_trans"));

            holder.cvBarangList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Activity_DaftarMeja.this, Activity_Keranjang.class)
                            .putExtra("id_meja", barang.get("id_meja"))
                            .putExtra("id_trans", barang.get("id_trans"));

                    startActivity(intent);
                    finish();
                }
            });

        }

        @Override
        public int getItemCount() {
            return barangList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {

            private View view;
            private TextView txtIdMeja, txtStsMeja, txtKetMeja;
            private CardView cvBarangList;

            public MyViewHolder(View view) {
                super(view);
                this.view = view;

                txtIdMeja = view.findViewById(R.id.txtIdMeja);
                txtKetMeja = view.findViewById(R.id.txtKetMeja);
                txtStsMeja = view.findViewById(R.id.txtStsMeja);
                cvBarangList = view.findViewById(R.id.cvListMeja);
            }
        }
    }
}
