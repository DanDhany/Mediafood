package com.dhany.mediafood;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import info.vividcode.android.zxing.CaptureActivity;
import info.vividcode.android.zxing.CaptureActivityIntents;


public class Fragmen_ScanMeja extends Fragment {

    Button btScan, bt_pesanMeja;
    TextView tvScanResult;

    public Fragmen_ScanMeja() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View fragmentView = inflater.inflate(R.layout.fragment_fragmen__scan_meja, container, false);
        btScan = fragmentView.findViewById(R.id.bt_scan);
        bt_pesanMeja=fragmentView.findViewById(R.id.bt_pesanMeja);
        tvScanResult = fragmentView.findViewById(R.id.tv_scanresult);
        btScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Membuat intent baru untuk memanggil CaptureActivity bawaan ZXing
                Intent captureIntent = new Intent(getActivity(), CaptureActivity.class);

                // Kemudian kita mengeset pesan yang akan ditampilkan ke user saat menjalankan QRCode scanning
                CaptureActivityIntents.setPromptMessage(captureIntent, "Scan QR pada meja kosong...");

                // Melakukan startActivityForResult, untuk menangkap balikan hasil dari QR Code scanning
                startActivityForResult(captureIntent, 0);

            }
        });
        return fragmentView;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 0) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                String value = data.getStringExtra("SCAN_RESULT");
                tvScanResult.setText(value);

                bt_pesanMeja.setVisibility(View.VISIBLE);
                bt_pesanMeja.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String[] action = {"updateMeja"};
                        new Fragmen_ScanMeja.DbWrite().execute(action);
                    }
                });


            } else if (resultCode == Activity.RESULT_CANCELED) {
                tvScanResult.setText("Scanning Gagal, mohon coba lagi.");
            }
        } else {

        }
        super.onActivityResult(requestCode, resultCode, data);
    }



    private String downloadUrl(String strUrl, @Nullable String idMeja, @Nullable String stsMeja) throws IOException {
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        String data = "";
        try {
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();

            if (idMeja != null || stsMeja != null) {
                urlConnection.setRequestMethod("POST");

                Uri.Builder builder = new Uri.Builder()
                        .appendQueryParameter("id_meja", idMeja)
                        .appendQueryParameter("sts_meja", stsMeja);
                String query = builder.build().getEncodedQuery();

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
            }

            urlConnection.connect();

            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            data = sb.toString();
            br.close();
        } catch (Exception e) {
            Log.d("Download URL", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }
    private class DbWrite extends AsyncTask<String, Integer, String> {

        @Override
        protected String doInBackground(String... strings) {
            String data = "";
            String action = strings[0];
            String idMeja = tvScanResult.getText().toString();
            String statusMeja = "dipesan" ;
            try {
                if (action.equals("updateMeja")) {
                    data = downloadUrl("http://192.168.1.69/UAS_MediaFood/update_meja.php", idMeja, statusMeja);
                }

                JSONObject jsonObject = new JSONObject(data);
                data = jsonObject.get("success").toString();
                Log.d("Blah", action + " - " + data);

            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s.equals("1")) {
                Toast.makeText(getContext(), "Meja Dipesan", Toast.LENGTH_SHORT).show();
//                setResult(RESULT_OK);
                Fragment fragmenu = new ListMenu();


            } else {
                Toast.makeText(getContext(), "Meja Tidak Kosong!", Toast.LENGTH_SHORT).show();
                bt_pesanMeja.setVisibility(View.INVISIBLE);
                btScan.setVisibility(View.VISIBLE);
            }
        }

    }



}
