package com.dhany.mediafood;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;


public class ListMeja extends Fragment {




    ListView listOrders;
    RecyclerView rvBarang;
    BarangAdapter barangAdapter;
    String searchQuery;
    ArrayList<HashMap<String, String>> itemList = new ArrayList<>();

    public ListMeja() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View fragmentView = inflater.inflate(R.layout.fragment_list_meja, container, false);
        listOrders = fragmentView.findViewById(R.id.listOrders);
        rvBarang = fragmentView.findViewById(R.id.rvBarang);

        barangAdapter = new BarangAdapter(itemList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        rvBarang.setLayoutManager(mLayoutManager);
        rvBarang.setItemAnimator(new DefaultItemAnimator());
        rvBarang.setAdapter(barangAdapter);

        new DbRead().execute("");

        return fragmentView;


    }

    private String downloadUrl(String strUrl, @Nullable String keyword) throws IOException {
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        String data = "";
        try {
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();

            if (keyword != null) {
                urlConnection.setRequestMethod("POST");

                Uri.Builder builder = new Uri.Builder().appendQueryParameter("keyword", keyword);
                String query = builder.build().getEncodedQuery();

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
            }

            urlConnection.connect();

            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            data = sb.toString();
            br.close();
        } catch (Exception e) {
            Log.d("Download URL", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }
    private class DbRead extends AsyncTask<String, Integer, String> {

        @Override
        protected String doInBackground(String... strings) {
            String data = "";
            itemList.clear();
            String keyword = strings[0];
            try {
                if (keyword.isEmpty()) {
                    data = downloadUrl("http://192.168.236.182/UAS_MediaFood/read_allmeja.php", null);
                } else {
                    data = downloadUrl("http://192.168.236.182/UAS_MediaFood/read_allmeja.php", keyword);
                }

                JSONObject jsonObject = new JSONObject(data);
                JSONArray barang = jsonObject.getJSONArray("meja");
                for (int i = 0; i < barang.length(); i++) {
                    JSONObject c = barang.getJSONObject(i);
                    String idMeja = c.getString("id_meja");
                    String ketMeja = c.getString("ket");
                    String stsMeja = c.getString("sts_meja");
                    HashMap<String, String> item = new HashMap<>();
                    item.put("id_meja", idMeja);
                    item.put("ket", ketMeja);
                    item.put("sts_meja", stsMeja);
                    itemList.add(item);
                }

            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

    }

    public class BarangAdapter extends RecyclerView.Adapter<BarangAdapter.MyViewHolder> {

        private ArrayList<HashMap<String, String>> barangList = new ArrayList<>();

        public BarangAdapter(ArrayList<HashMap<String, String>> barangList) {
            this.barangList = barangList;
        }

        @Override
        public BarangAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_meja, parent, false);

            return new BarangAdapter.MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final BarangAdapter.MyViewHolder holder, int position) {

            final HashMap<String, String> barang = barangList.get(position);

            holder.txtIdMeja.setText("No Meja\t\t\t: " + barang.get("id_meja"));
            holder.txtKetMeja.setText("Ket\t: " + barang.get("ket"));
            holder.txtStsMeja.setText("Status Meja\t: " + barang.get("sts_meja"));

            holder.cvBarangList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), Activity_ScanQR.class);
                    startActivity(intent);
                }
            });

        }

        @Override
        public int getItemCount() {
            return barangList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {

            private View view;
            private TextView txtIdMeja, txtStsMeja, txtKetMeja;
            private CardView cvBarangList;

            public MyViewHolder(View view) {
                super(view);
                this.view = view;

                txtIdMeja = view.findViewById(R.id.txtIdMeja);
                txtKetMeja = view.findViewById(R.id.txtKetMeja);
                txtStsMeja = view.findViewById(R.id.txtStsMeja);
                cvBarangList = view.findViewById(R.id.cvListMeja);
            }
        }
    }

}
