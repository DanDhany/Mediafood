package com.dhany.mediafood;

import android.Manifest;
import android.content.Intent;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity_MenuUtama extends AppCompatActivity {
    Button bt_menu, bt_meja, bt_pesan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__menu_utama);

        bt_menu = (Button)findViewById(R.id.bt_menu);
        bt_meja = (Button)findViewById(R.id.bt_meja);
        bt_pesan = (Button)findViewById(R.id.bt_pesan);

        bt_meja.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity_MenuUtama.this, Activity_DaftarMeja.class);
                startActivity(intent);
            }
        });
        bt_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity_MenuUtama.this, Activity_DaftarMenu.class);
                startActivity(intent);
            }
        });
        bt_pesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity_MenuUtama.this, Activity_ScanQR.class);
                startActivity(intent);
            }
        });


        ActivityCompat.requestPermissions(Activity_MenuUtama.this, new String[]{Manifest.permission.CAMERA}, 1111);
        ActivityCompat.requestPermissions(Activity_MenuUtama.this, new String[]{Manifest.permission.INTERNET}, 1111);

    }
}
