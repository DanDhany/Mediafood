package com.dhany.mediafood;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Random;

public class Activity_MenuPesan extends AppCompatActivity {

    ListView listOrders;
    RecyclerView rvBarang;
    Activity_MenuPesan.BarangAdapter barangAdapter;
    String searchQuery;
    ArrayList<HashMap<String, String>> itemList = new ArrayList<>();
    TextView txtIdTrans, txtIdMeja, dateView;
    Button btnPesanMenu;

    private DatePicker datePicker;
    private Calendar calendar;
    private int year, month, day, counter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__menu_pesan);


        listOrders = (ListView) findViewById(R.id.listOrders);
        rvBarang = (RecyclerView) findViewById(R.id.rvBarang);

        txtIdMeja = (TextView)findViewById(R.id.txtIdMeja);
        txtIdTrans = (TextView)findViewById(R.id.txtIdTrans);
        dateView = (TextView)findViewById(R.id.textView3);

        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        showDate(year, month + 1, day);

        barangAdapter = new Activity_MenuPesan.BarangAdapter(itemList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(Activity_MenuPesan.this    );
        rvBarang.setLayoutManager(mLayoutManager);
        rvBarang.setItemAnimator(new DefaultItemAnimator());
        rvBarang.setAdapter(barangAdapter);

        Random r = new Random();
        int randomNumber = r.nextInt(666);
        txtIdTrans.setText("T"+String.valueOf(randomNumber));;

        Intent i = getIntent();
        txtIdMeja.setText(i.getStringExtra("sendid"));

        new DbRead().execute("");

        btnPesanMenu = (Button)findViewById(R.id.btnPesanMenu);

        btnPesanMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Activity_MenuPesan.this, Activity_Keranjang.class)
                        .putExtra("id_trans", txtIdTrans.getText().toString())
                        .putExtra("id_meja", txtIdMeja.getText().toString())
                        .putExtra("tgl_trans", dateView.getText().toString());
                i.setAction("edit");
                startActivityForResult(i, 222);

            }
        });

        final Handler handler = new Handler();
        Runnable refresh = new Runnable() {
            @Override
            public void run() {
                new Activity_MenuPesan.DbRead().execute("");
                handler.postDelayed(this, 3 * 1000);
            }
        };
        handler.postDelayed(refresh, 3 * 1000);



    }

    @Override
    public void onBackPressed() {
        Toast.makeText(getApplicationContext(), "Selesaikan Pesanan Anda!", Toast.LENGTH_SHORT).show();
    }

    private String downloadUrl(String strUrl, @Nullable String keyword) throws IOException {
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        String data = "";
        try {
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();

            if (keyword != null) {
                urlConnection.setRequestMethod("POST");

                Uri.Builder builder = new Uri.Builder().appendQueryParameter("keyword", keyword);
                String query = builder.build().getEncodedQuery();

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
            }

            urlConnection.connect();

            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            data = sb.toString();
            br.close();
        } catch (Exception e) {
            Log.d("Download URL", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }
    private class DbRead extends AsyncTask<String, Integer, String> {

        @Override
        protected String doInBackground(String... strings) {
            String data = "";
            itemList.clear();
            String keyword = strings[0];
            try {
                if (keyword.isEmpty()) {
                    data = downloadUrl("http://192.168.43.134/UAS_MediaFood/read_allmenu.php", null);
                } else {
                    data = downloadUrl("http://192.168.43.134/UAS_MediaFood/read_allmenu.php", keyword);
                }

                JSONObject jsonObject = new JSONObject(data);
                JSONArray barang = jsonObject.getJSONArray("meja");
                for (int i = 0; i < barang.length(); i++) {
                    JSONObject c = barang.getJSONObject(i);
                    String idMenu = c.getString("id_menu");
                    String nmMenu = c.getString("nama_menu");
                    String hrgMenu = c.getString("hrg_menu");
                    String stsMenu = c.getString("sts_menu");
                    HashMap<String, String> item = new HashMap<>();
                    item.put("id_menu", idMenu);
                    item.put("nama_menu", nmMenu);
                    item.put("hrg_menu", hrgMenu);
                    item.put("sts_menu", stsMenu);
                    itemList.add(item);
                }

            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            barangAdapter.notifyDataSetChanged();
        }

    }

    public class BarangAdapter extends RecyclerView.Adapter<Activity_MenuPesan.BarangAdapter.MyViewHolder> {

        private ArrayList<HashMap<String, String>> barangList = new ArrayList<>();

        public BarangAdapter(ArrayList<HashMap<String, String>> barangList) {
            this.barangList = barangList;
        }

        @Override
        public Activity_MenuPesan.BarangAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_menu, parent, false);

            return new Activity_MenuPesan.BarangAdapter.MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final Activity_MenuPesan.BarangAdapter.MyViewHolder holder, int position) {

            final HashMap<String, String> barang = barangList.get(position);

            holder.txtIdMenu.setText("ID Menu\t\t\t: " + barang.get("id_menu"));
            holder.txtNamaMenu.setText("Nama Menu\t: " + barang.get("nama_menu"));
            holder.txtHrgMenu.setText("Harga\t: " + barang.get("hrg_menu"));
            holder.txtStsMenu.setText("Status \t: " + barang.get("sts_menu"));

            holder.cvMenuList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Activity_MenuPesan.this, Activity_Pesan.class)

                            .putExtra("id_menu", barang.get("id_menu"))
                            .putExtra("nama_menu", barang.get("nama_menu"))
                            .putExtra("hrg_menu", barang.get("hrg_menu"))
                            .putExtra("id_trans", txtIdTrans.getText().toString())
                            .putExtra("id_meja", txtIdMeja.getText().toString())
                            .putExtra("tgl_trans", dateView.getText().toString());
                    i.setAction("tambah");
                    startActivityForResult(i, 222);
                }
            });


        }

        @Override
        public int getItemCount() {
            return barangList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {

            private View view;
            private TextView txtIdMenu, txtHrgMenu, txtNamaMenu, txtStsMenu;
            private CardView cvMenuList;

            public MyViewHolder(View view) {
                super(view);
                this.view = view;

                txtIdMenu = view.findViewById(R.id.txtIdMenu);
                txtNamaMenu = view.findViewById(R.id.txtNamaMenu);
                txtHrgMenu = view.findViewById(R.id.txtHargaMenu);
                txtStsMenu = view.findViewById(R.id.txtStsMenu);
                cvMenuList = view.findViewById(R.id.cvListMenu);
            }
        }
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this, myDateListener, year, month, day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
            // TODO Auto-generated method stub
            // arg1 = year
            // arg2 = month
            // arg3 = day
            showDate(arg1, arg2+1, arg3);
        }
    };

    private void showDate(int year, int month, int day) {
        dateView.setText(new StringBuilder().append(day).append("/").append(month).append("/").append(year));
    }


}
