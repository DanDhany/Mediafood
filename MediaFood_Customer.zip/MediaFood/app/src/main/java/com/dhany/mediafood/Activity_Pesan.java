package com.dhany.mediafood;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class Activity_Pesan extends AppCompatActivity {

    EditText etIdBarangUbah, etNamaBarangUbah, etHargaBarangUbah, jml;
    Button btnPesan, btnTambah ,btnKurang, btnPesanMenu, btnUbahMenu, btnHapusMenu;
    int counter=0;
    String id_Trans, id_Meja, tgl_trans;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__pesan);

        etIdBarangUbah = findViewById(R.id.etIdBarangUbah);
        etNamaBarangUbah = findViewById(R.id.etNamaBarangUbah);
        etHargaBarangUbah = findViewById(R.id.etHargaBarangUbah);
        jml = findViewById(R.id.jml);
        btnPesan = findViewById(R.id.btnPesanMenu);
        btnUbahMenu = findViewById(R.id.btnUbahMenu);
        btnTambah = findViewById(R.id.btnPlus);
        btnKurang = findViewById(R.id.btnMinus);
        btnHapusMenu = findViewById(R.id.btnHapusMenu);

        Intent i = getIntent();
        if (i.getAction().equals("edit")) {
            btnPesan.setVisibility(View.GONE);
            btnUbahMenu.setVisibility(View.VISIBLE);
            btnHapusMenu.setVisibility(View.VISIBLE);
        } else if (i.getAction().equals("tambah")){
            btnPesan.setVisibility(View.VISIBLE);
            btnHapusMenu.setVisibility(View.GONE);
            btnUbahMenu.setVisibility(View.GONE);
        }
        etIdBarangUbah.setText(i.getStringExtra("id_menu"));
        etNamaBarangUbah.setText(i.getStringExtra("nama_menu"));
        etHargaBarangUbah.setText(i.getStringExtra("hrg_menu"));
        id_Trans = i.getStringExtra("id_trans");
        id_Meja = i.getStringExtra("id_meja");
        tgl_trans = i.getStringExtra("tgl_trans");

        counter = 0;

        btnTambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Adds 1 to the counter
                counter = counter + 1;
                jml.setText(String.valueOf(counter));
            }
        });
        btnKurang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Subtract 1 from counter
                if(counter>0) {
                    counter = counter - 1;
                    jml.setText(String.valueOf(counter));
                }else{
                    jml.setText("0");
                }
            }
        });
        btnPesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFilledAll()) {
                    String[] action = {"insert"};
                    new DbWrite().execute(action);
                }
            }
        });
        btnUbahMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFilledAll()) {
                    String[] action = {"update"};
                    new DbWrite().execute(action);
                    Toast.makeText(getApplicationContext(), "Ubah Menu Berhasil!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnHapusMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    String[] action = {"delete"};
                    new DbWrite().execute(action);

                Toast.makeText(getApplicationContext(), "Hapus Menu Berhasil!", Toast.LENGTH_SHORT).show();
            }
        });

    }
    private boolean isFilledAll() {
        if (jml.getText().toString().isEmpty() || jml.getText().toString().equalsIgnoreCase("0")) {
            Toast.makeText(Activity_Pesan.this, "Masukkan Jumlah Pesanan!", Toast.LENGTH_SHORT);
            return false;
        }
        return true;
    }

    private String downloadUrl(String strUrl, @Nullable String idTrans, @Nullable String idMenu, @Nullable String namaMenu, @Nullable String hrgMenu, @Nullable String jmlPesan, @Nullable String idMeja, @Nullable String tglTrans) throws IOException {
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        String data = "";
        try {
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();

            if (idTrans != null || idMenu != null || namaMenu != null || hrgMenu != null || jmlPesan != null || idMeja != null || tglTrans != null) {
                urlConnection.setRequestMethod("POST");

                Uri.Builder builder = new Uri.Builder()
                        .appendQueryParameter("id_trans", idTrans)
                        .appendQueryParameter("id_menu", idMenu)
                        .appendQueryParameter("nama_menu", namaMenu)
                        .appendQueryParameter("hrg_menu", hrgMenu)
                        .appendQueryParameter("jml_pesan", jmlPesan)
                        .appendQueryParameter("id_meja", idMeja)
                        .appendQueryParameter("tgl_trans", tglTrans);
                String query = builder.build().getEncodedQuery();

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
            }

            urlConnection.connect();

            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            data = sb.toString();
            br.close();
        } catch (Exception e) {
            Log.d("Download URL", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    private class DbWrite extends AsyncTask<String, Integer, String> {

        @Override
        protected String doInBackground(String... strings) {
            String data = "";
            String action = strings[0];
            String idTrans = id_Trans;
            String idMeja = id_Meja;
            String tglTrans = tgl_trans;
            String idMenu = etIdBarangUbah.getText().toString();
            String NamaMenu = etNamaBarangUbah.getText().toString();
            String hrgMenu = etHargaBarangUbah.getText().toString();
            String jmlPesan = jml.getText().toString();
            try {
                if (action.equals("insert")) {
                    data = downloadUrl("http://192.168.43.134/UAS_MediaFood/take_order.php", idTrans, idMenu, NamaMenu, hrgMenu, jmlPesan, idMeja, tglTrans);
                } else if (action.equals("update")) {
                    data = downloadUrl("http://192.168.43.134/UAS_MediaFood/update_order.php", idTrans, idMenu, NamaMenu, hrgMenu, jmlPesan, idMeja, tglTrans);
                } else if (action.equals("delete")) {
                    data = downloadUrl("http://192.168.43.134/UAS_MediaFood/delete_order.php", idTrans, idMenu, NamaMenu, hrgMenu, jmlPesan, idMeja, tglTrans);
                }

                JSONObject jsonObject = new JSONObject(data);
                data = jsonObject.get("success").toString();
                Log.d("Blah", action + " - " + data);

            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s.equals("1")) {
                Toast.makeText(getApplicationContext(), "Proses Menu Berhasil!", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            } else {
                Toast.makeText(getApplicationContext(), "Proses Menu Gagal!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
